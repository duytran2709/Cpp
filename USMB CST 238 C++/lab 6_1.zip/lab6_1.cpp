/*
* Title: lab6_1.cpp
* Abstract: This program is created a class, implementation for the class,and a driver
* to provide a service of a bank.
* Author: Thach Dang
* ID: 3555
* Date: 10/14/2013
*/
//--- Test driver for class Account 
 
#include <iostream> 

using namespace std; 

#include "Account.h" 
 
int main() 
{ 
 bool flag; 
 Account chase ("John", 1000, 1, 10, 50); 
 Account citi ("Tom", 2000, 2, 10, 50); 
 
 flag = (chase == citi); 
 cout << "Chase account: " << chase << endl; 
 cout << "Citi account: " << citi << endl; 
 cout << "Chase == Citi: " << flag << endl << endl; 
 
 chase.deposit (4, 75); 
 citi. deposit (5, 10); 
 flag = (chase > citi); 
 cout << "Chase account: " << chase << endl; 
 cout << "Citi account: " << citi << endl; 
 cout << "Chase > Citi: " << flag << endl << endl; 
 
 chase.withdrawal (4, 75); 
 citi. withdrawal (5, 15); 
 flag = (chase == citi); 
 cout << "Chase account: " << chase << endl; 
 cout << "Citi account: " << citi << endl; 
 cout << "Chase == Citi: " << flag << endl << endl; 
 
 return 0; 
 
} 