/*
* Title: lab6_1.cpp
* Abstract: This program is created a class, implementation for the class,and a driver
* to provide a service of a bank.
* This is the class Account prototype.
* Author: Thach Dang
* ID: 3555
* Date: 10/14/2013
*/
# include <iostream>
# include <string>

using namespace std;

class Account
{
public:  // public functions
	// Two constructors
	Account();
	Account(string oname, int oacc_num, int oacc_type, int odollar, int ocent);
	bool deposit(int odollar, int ocent);  // deposit method
	bool withdrawal(int odollar, int ocent);  // withdraw method
	void display(ostream &out) const;  // display function used to help for operator<<
	int gettotal();  // gettotal function used to help for two compare functions.
private:  //private data member
	string name;
	int acc_num;
	int acc_type;
	int dollar, cent, total_cents;
};
// Ordinary functions
ostream & operator<<(ostream & out, const Account & t);
bool operator>(Account &acc1, Account &acc2);
bool operator==(Account &acc1, Account &acc2);