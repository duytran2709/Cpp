/*
* Title: lab6_1.cpp
* Abstract: This program is created a class, implementation for the class,and a driver
* to provide a service of a bank.
* This is the class Account implementation.
* Author: Thach Dang
* ID: 3555
* Date: 10/14/2013
*/
# include <iostream>
# include <string>

using namespace std;

#include "Account.h"

Account::Account()
{
	name = "UNKNOWN";
	acc_num = 9999;
	acc_type = 2;
	dollar = 0;
	cent = 0;
	total_cents = 0;
}
Account::Account(string oname, int oacc_num, int oacc_type, int odollar, int ocent)
{
	if(oacc_num >= 1000 && oacc_num <= 9999)
		acc_num = oacc_num;
	if(oacc_type == 1 || oacc_type == 2)
		acc_type = oacc_type;
	dollar = odollar;
	cent = ocent;
	name = oname;
	total_cents = dollar*100 + cent;
}
bool Account::deposit(int odollar, int ocent)
{
	int total_deposit;
	total_deposit = odollar*100 + ocent;
	if(total_deposit > 0)
	{
		total_cents += total_deposit;
		dollar = total_cents/100;
		cent = total_cents%100;
		return true;
	}
	else
		return false;
}
bool Account::withdrawal(int odollar, int ocent)
{
	int total_withdraw = odollar*100 + ocent;
	if(total_withdraw < total_cents)
	{
		total_cents -= total_withdraw;
		dollar = total_cents/100;
		cent = total_cents%100;
		return true;
	}
	else
		return false;
}
void Account::display(ostream & out) const
{
    out << endl;
	out << "Account name: " << name << endl;
    out << "Account number: " << acc_num << endl;
    out << "Current balance: $" << dollar  << "." << cent << endl;
    out << "Total cents: " << total_cents  << endl;
}
int Account::gettotal()
{
	return total_cents;
}
bool operator>(Account &acc1, Account &acc2)
{
	if(acc1.gettotal() > acc2.gettotal())
		return true;
	else
		return false;
}
bool operator==(Account &acc1, Account &acc2)
{
	if(acc1.gettotal() == acc2.gettotal())
		return true;
	else
		return false;
}
ostream & operator<<(ostream & out, const Account & acc)
{
	acc.display(out);
	return out;
}

